const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const COUNTY_CONFIG = {
  'kaufman': {
    name: 'Kaufman County',
    taxUrl: 'https://www.kaufman.tx.us/appraisal/',
    cadUrl: 'https://www.kaufmangis.com/',
    fipsCode: '48257'
  },
  'dallas': {
    name: 'Dallas County',
    taxUrl: 'https://www.dallascad.org/',
    cadUrl: 'https://gis.dallascountytx.gov/',
    fipsCode: '48113'
  },
  'tarrant': {
    name: 'Tarrant County',
    taxUrl: 'https://www.tarrantcad.com/',
    cadUrl: 'https://www.tarrantcad.com/Home/PropertySearch',
    fipsCode: '48439'
  },
  'henderson': {
    name: 'Henderson County',
    taxUrl: 'https://www.hendersontx.org/',
    cadUrl: 'https://hendersongis.com/',
    fipsCode: '48213'
  },
  'grayson': {
    name: 'Grayson County',
    taxUrl: 'https://www.graysonestatesappraisal.com/',
    cadUrl: 'https://graysonsgis.com/',
    fipsCode: '48181'
  },
  'howard': {
    name: 'Howard County',
    taxUrl: 'https://www.howard.tx.us/appraisal/',
    cadUrl: 'https://howardgis.com/',
    fipsCode: '48227'
  },
  'montague': {
    name: 'Montague County',
    taxUrl: 'https://www.montaguecountytx.com/',
    cadUrl: 'https://montaguegis.com/',
    fipsCode: '48349'
  }
};

async function getCoordinates(address) {
  try {
    const response = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`);
    const data = await response.json();
    if (!data || data.length === 0) return null;
    return {
      lat: parseFloat(data[0].lat),
      lon: parseFloat(data[0].lon),
      displayName: data[0].display_name
    };
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
}

async function checkFloodZone(lat, lon) {
  try {
    const response = await fetch(`https://hazards.fema.gov/gis/rest/services/public/FEMA_NFHL/MapServer/identify?geometry={"x":${lon},"y":${lat}}&geometryType=esriGeometryPoint&layers=all&tolerance=1&mapExtent=-180,-90,180,90&imageDisplay=400,300,96&f=json`);
    const data = await response.json();
    
    let floodZone = 'Zone X (Low risk)';
    let floodRisk = 'low';
    
    if (data.results && data.results.length > 0) {
      const result = data.results[0];
      if (result.attributes && result.attributes.FLD_ZONE) {
        floodZone = result.attributes.FLD_ZONE;
        if (floodZone.includes('A') || floodZone.includes('V')) {
          floodRisk = 'high';
        } else if (floodZone.includes('X')) {
          floodRisk = 'low';
        }
      }
    }
    
    return { floodZone, floodRisk };
  } catch (error) {
    console.error('Flood zone check error:', error);
    return { floodZone: 'Unable to verify', floodRisk: 'unknown' };
  }
}

function detectCounty(displayName) {
  const nameLower = displayName.toLowerCase();
  for (const [key, config] of Object.entries(COUNTY_CONFIG)) {
    if (nameLower.includes(key)) {
      return key;
    }
  }
  return 'kaufman';
}

function generateLeveragePoints(floodRisk, county) {
  const points = [];
  
  if (floodRisk === 'high') {
    points.push('⚠️ HIGH FLOOD RISK - Major leverage');
  } else {
    points.push('✓ Clear flood zone');
  }
  
  points.push('📋 Verify with county CAD');
  points.push('🔍 Check for liens/delinquencies');
  points.push('📐 Assess lot shape in GIS');
  points.push('🚫 Confirm road access');
  
  return points;
}

app.post('/api/research', async (req, res) => {
  const { address } = req.body;
  
  if (!address || address.trim() === '') {
    return res.status(400).json({ error: 'Please enter a property address' });
  }
  
  try {
    const coords = await getCoordinates(address);
    if (!coords) {
      return res.status(404).json({ error: 'Property not found. Try a more specific address (include city and state)' });
    }
    
    const county = detectCounty(coords.displayName);
    const countyConfig = COUNTY_CONFIG[county];
    
    const floodData = await checkFloodZone(coords.lat, coords.lon);
    
    const leveragePoints = generateLeveragePoints(floodData.floodRisk, county);
    
    const mapsLink = `https://maps.google.com/?q=${coords.lat},${coords.lon}`;
    const coordinatesText = `${coords.lat.toFixed(4)}, ${coords.lon.toFixed(4)}`;
    
    res.json({
      success: true,
      data: {
        address: coords.displayName.split(',').slice(0, 3).join(',').trim(),
        coordinates: coordinatesText,
        lat: coords.lat,
        lon: coords.lon,
        mapsLink,
        county: countyConfig.name,
        countyKey: county,
        taxUrl: countyConfig.taxUrl,
        cadUrl: countyConfig.cadUrl,
        floodZone: floodData.floodZone,
        floodRisk: floodData.floodRisk,
        leveragePoints
      }
    });
  } catch (error) {
    console.error('Research error:', error);
    res.status(500).json({ error: 'Error researching property. Please try again.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Property Research Tool running on port ${PORT}`);
});

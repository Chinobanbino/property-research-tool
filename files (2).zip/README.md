# Property Research Tool for Ed

Fast, automated property pre-qualification research tool that cuts Ed's due diligence time from 15+ minutes to **2–3 minutes per lead**.

## Features

✅ **One-click address lookup** — Search by address, get instant results
✅ **Real FEMA flood zone integration** — Automatically checks flood risk zones
✅ **County-specific tax assessor links** — Kaufman, Dallas, Henderson, Grayson, Howard, Montague
✅ **Direct GIS/CAD links** — Jump straight to county mapping systems
✅ **Leverage points summary** — Pre-call talking points pre-generated
✅ **Copy-to-clipboard** — Paste coordinates and notes directly into Podio
✅ **Mobile-friendly** — Works on desktop and mobile

## Supported Counties

- **Kaufman** (primary)
- Dallas
- Tarrant (Fort Worth area)
- Henderson
- Grayson
- Howard
- Montague

(Easy to add more—just extend `COUNTY_CONFIG` in `server.js`)

---

## Quick Start (Local)

### 1. Clone or download this project

```bash
cd property-research-tool
npm install
```

### 2. Start the server

```bash
npm start
```

The tool will be available at `http://localhost:3000`

### 3. Test it

- Open http://localhost:3000
- Enter an address like `123 Main St, McKinney, TX`
- Click **Research**

---

## Deploy to Railway (5 minutes)

Railway is the fastest way to go live. No Docker knowledge needed.

### Step 1: Create a GitHub repo (optional but recommended)

If you don't have GitHub, create one free at https://github.com

```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_USERNAME/property-research-tool.git
git branch -M main
git push -u origin main
```

### Step 2: Deploy to Railway

1. Go to **https://railway.app**
2. Click **Create New Project**
3. Select **Deploy from GitHub repo** (or **Deploy from URL** if you don't have GitHub)
4. Select this repo
5. Railway will auto-detect `package.json` and `server.js`
6. Click **Deploy**
7. Wait ~2 minutes for deployment to complete
8. Railway gives you a public URL → **that's your live tool**

### Step 3: Share the URL with Ed

Once deployed, Railway provides a public URL like:
```
https://property-research-tool-prod.up.railway.app
```

Ed can bookmark it, access it from any device, and start researching properties instantly.

---

## How Ed Uses It

**Workflow:**

1. **Open the tool** (bookmarked in browser)
2. **Enter address** (e.g., "123 Main St, McKinney, TX")
3. **Click Research** → 2 seconds later:
   - ✓ Coordinates (copy to Podio)
   - ✓ Flood zone status (red/green flag)
   - ✓ Tax assessor link (click to check delinquencies)
   - ✓ County GIS link (verify lot shape, topography)
   - ✓ Leverage points (what to mention on the call)
4. **Call the seller** with researched talking points
5. **Save into Podio** once Jal finalizes offer numbers

**Time saved:** ~12 minutes per lead when researching 30–40 calls/day = **6+ hours per week**

---

## Customization

### Add more counties

In `server.js`, add to `COUNTY_CONFIG`:

```javascript
'yourCounty': {
  name: 'Your County Name',
  taxUrl: 'https://your.county.tax.url',
  cadUrl: 'https://your.county.gis.url',
  fipsCode: '48XXX'
}
```

### Change flood zone source

The tool uses FEMA's free REST API. If you want different flood data:
- **Zillow API**: Sign up for Zillow's property API (paid)
- **Google Maps API**: Integrate for property details
- **CoreLogic**: For deeper property research (paid enterprise)

### Integrate into Podio

The tool outputs data in copy-friendly format. You can:

1. **Copy coordinates** directly into Podio address field
2. **Copy leverage points** into notes
3. **Paste links** into custom fields for easy reference

Or build a Podio webhook integration if you want automated intake creation.

---

## Tech Stack

- **Backend**: Node.js + Express
- **Frontend**: Vanilla HTML/CSS/JavaScript (no frameworks needed)
- **APIs**: 
  - OpenStreetMap Nominatim (geocoding—free)
  - FEMA NFHL (flood zones—free)
  - County GIS systems (direct links)
- **Hosting**: Railway

---

## Environment Variables

Create a `.env` file (copy from `.env.example`):

```
PORT=3000
NODE_ENV=production
```

Railway auto-detects and sets these if needed.

---

## Troubleshooting

**"Property not found"**
- Address format: include city and state (e.g., "123 Main St, McKinney, Texas")
- Try a more specific address or nearby cross street

**"Flood zone check unavailable"**
- FEMA API occasionally has rate limits
- Try again in 30 seconds
- Falls back to "Unable to verify" safely

**Tool is slow to load**
- First request cold-starts the server (~2 sec)
- Subsequent requests are fast
- Railway keeps it warm automatically

**Links aren't working**
- County URLs occasionally change
- Open a GitHub issue or Slack Giovanni with the broken link
- Will update within 24 hours

---

## Future Enhancements

Planned:

- [ ] **Zillow/Redfin integration** for recent comp prices and estimated ARV
- [ ] **Property tax history** (5-year trend)
- [ ] **Deed restriction lookup** (HOA, easements)
- [ ] **Bulk research export** (CSV for multiple leads)
- [ ] **Podio webhook** (auto-create intakes from research)
- [ ] **SMS to Podio** (Ed texts an address, gets research back)

---

## Support

For issues or feature requests:

1. **Tech issues**: Open a GitHub issue
2. **Deployment help**: Email Giovanni
3. **Feature requests**: Chat with Giovanni

---

## License

MIT — Use freely, modify as needed.

---

**Built for Ed's pre-qualification workflow.**  
*Cuts research time from 15+ min to 2–3 min per lead.*
